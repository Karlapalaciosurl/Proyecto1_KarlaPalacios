#pragma once
#include "Pila.h"
#include "Nodo.h"
namespace Poyecto1KarlaPalacios1173219 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	/// <summary>
	/// Summary for Medio
	/// </summary>
	public ref class Medio : public System::Windows::Forms::Form
	{
	public:
		Pila* mipila1;
		Pila* mipila2;
		Pila* mipila3;
		Pila* mipila4;
		String^ Pasos = "";
	private: System::Windows::Forms::Button^ btnAyuda;
	private: System::Windows::Forms::ListBox^ listP3;
	private: System::Windows::Forms::ListBox^ listP2;
	private: System::Windows::Forms::ListBox^ listP1;
	private: System::Windows::Forms::ListBox^ listP0;
	public:
		int Movimientos;
		Medio(void)
		{
			InitializeComponent();
			mipila1 = new Pila();
			mipila1->count = 0;
			mipila1->start = nullptr;
			mipila1->end = nullptr;
			mipila2 = new Pila();
			mipila2->count = 0;
			mipila2->start = nullptr;
			mipila2->end = nullptr;
			mipila3 = new Pila();
			mipila3->count = 0;
			mipila3->start = nullptr;
			mipila3->end = nullptr;
			mipila4 = new Pila();
			mipila4->count = 0;
			mipila4->start = nullptr;
			mipila4->end = nullptr;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Medio()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ lblMovimientos;
	protected:
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ txtPilaDestino;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ txtPilaOrigen;
	private: System::Windows::Forms::Label^ label1;




	private: System::Windows::Forms::Button^ btnMover;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblMovimientos = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtPilaDestino = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtPilaOrigen = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnMover = (gcnew System::Windows::Forms::Button());
			this->btnAyuda = (gcnew System::Windows::Forms::Button());
			this->listP3 = (gcnew System::Windows::Forms::ListBox());
			this->listP2 = (gcnew System::Windows::Forms::ListBox());
			this->listP1 = (gcnew System::Windows::Forms::ListBox());
			this->listP0 = (gcnew System::Windows::Forms::ListBox());
			this->SuspendLayout();
			// 
			// lblMovimientos
			// 
			this->lblMovimientos->AutoSize = true;
			this->lblMovimientos->Location = System::Drawing::Point(291, 9);
			this->lblMovimientos->Name = L"lblMovimientos";
			this->lblMovimientos->Size = System::Drawing::Size(13, 13);
			this->lblMovimientos->TabIndex = 29;
			this->lblMovimientos->Text = L"_";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(216, 9);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(69, 13);
			this->label7->TabIndex = 28;
			this->label7->Text = L"Movimientos:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(-1, 276);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(282, 13);
			this->label6->TabIndex = 27;
			this->label6->Text = L"Ingrese el n�mero de Pila a la cual desea mover el bloque:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(-1, 225);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(318, 13);
			this->label5->TabIndex = 26;
			this->label5->Text = L"Ingrese el n�mero de Pila de la cual desea mover el �ltimo bloque:";
			// 
			// txtPilaDestino
			// 
			this->txtPilaDestino->Location = System::Drawing::Point(140, 293);
			this->txtPilaDestino->Name = L"txtPilaDestino";
			this->txtPilaDestino->Size = System::Drawing::Size(59, 20);
			this->txtPilaDestino->TabIndex = 25;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(225, 43);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(20, 13);
			this->label4->TabIndex = 24;
			this->label4->Text = L"P3";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(182, 43);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(20, 13);
			this->label3->TabIndex = 23;
			this->label3->Text = L"P2";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(137, 43);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(20, 13);
			this->label2->TabIndex = 22;
			this->label2->Text = L"P1";
			// 
			// txtPilaOrigen
			// 
			this->txtPilaOrigen->Location = System::Drawing::Point(140, 243);
			this->txtPilaOrigen->Name = L"txtPilaOrigen";
			this->txtPilaOrigen->Size = System::Drawing::Size(59, 20);
			this->txtPilaOrigen->TabIndex = 21;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(94, 43);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(20, 13);
			this->label1->TabIndex = 20;
			this->label1->Text = L"P0";
			// 
			// btnMover
			// 
			this->btnMover->Location = System::Drawing::Point(133, 323);
			this->btnMover->Name = L"btnMover";
			this->btnMover->Size = System::Drawing::Size(75, 23);
			this->btnMover->TabIndex = 15;
			this->btnMover->Text = L"Mover";
			this->btnMover->UseVisualStyleBackColor = true;
			this->btnMover->Click += gcnew System::EventHandler(this, &Medio::btnMover_Click);
			// 
			// btnAyuda
			// 
			this->btnAyuda->Location = System::Drawing::Point(8, 7);
			this->btnAyuda->Name = L"btnAyuda";
			this->btnAyuda->Size = System::Drawing::Size(75, 23);
			this->btnAyuda->TabIndex = 30;
			this->btnAyuda->Text = L"Ayuda";
			this->btnAyuda->UseVisualStyleBackColor = true;
			this->btnAyuda->Click += gcnew System::EventHandler(this, &Medio::btnAyuda_Click);
			// 
			// listP3
			// 
			this->listP3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->listP3->FormattingEnabled = true;
			this->listP3->Location = System::Drawing::Point(214, 61);
			this->listP3->Name = L"listP3";
			this->listP3->Size = System::Drawing::Size(43, 147);
			this->listP3->TabIndex = 34;
			// 
			// listP2
			// 
			this->listP2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->listP2->FormattingEnabled = true;
			this->listP2->Location = System::Drawing::Point(172, 61);
			this->listP2->Name = L"listP2";
			this->listP2->Size = System::Drawing::Size(43, 147);
			this->listP2->TabIndex = 33;
			// 
			// listP1
			// 
			this->listP1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listP1->FormattingEnabled = true;
			this->listP1->Location = System::Drawing::Point(130, 61);
			this->listP1->Name = L"listP1";
			this->listP1->Size = System::Drawing::Size(43, 147);
			this->listP1->TabIndex = 32;
			// 
			// listP0
			// 
			this->listP0->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->listP0->FormattingEnabled = true;
			this->listP0->Location = System::Drawing::Point(88, 61);
			this->listP0->Name = L"listP0";
			this->listP0->Size = System::Drawing::Size(43, 147);
			this->listP0->TabIndex = 31;
			// 
			// Medio
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::PaleGoldenrod;
			this->ClientSize = System::Drawing::Size(341, 354);
			this->Controls->Add(this->listP3);
			this->Controls->Add(this->listP2);
			this->Controls->Add(this->listP1);
			this->Controls->Add(this->listP0);
			this->Controls->Add(this->btnAyuda);
			this->Controls->Add(this->lblMovimientos);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtPilaDestino);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtPilaOrigen);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnMover);
			this->Name = L"Medio";
			this->Text = L"Medio";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &Medio::Medio_FormClosing);
			this->Load += gcnew System::EventHandler(this, &Medio::Medio_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		void LlenarPila1() {
			Nodo* temp = mipila1->start;
			listP0->Items->Clear();
			while (temp != nullptr) {
				if (temp->value == 65)
				{
					listP0->Items->Add("A");
					listP0->BackColor.Yellow;
				}
				if (temp->value == 77)
				{
					listP0->Items->Add("M");
					listP0->BackColor.Purple;
				}
				if (temp->value == 82)
				{
					listP0->Items->Add("R");
					listP0->BackColor.Red;
				}
				if (temp->value == 86)
				{
					listP0->Items->Add("V");
					listP0->BackColor.Green;
				}
				temp = temp->next;
			}
		}
		void LlenarPila2() {
			Nodo* temp = mipila2->start;
			listP1->Items->Clear();
			while (temp != nullptr) {
				if (temp->value == 65)
				{
					listP1->Items->Add("A");
				}
				if (temp->value == 77)
				{
					listP1->Items->Add("M");
				}
				if (temp->value == 82)
				{
					listP1->Items->Add("R");
				}
				if (temp->value == 86)
				{
					listP1->Items->Add("V");
				}
				temp = temp->next;
			}
		}
		void LlenarPila3() {
			Nodo* temp = mipila3->start;
			listP2->Items->Clear();
			while (temp != nullptr) {
				if (temp->value == 65)
				{
					listP2->Items->Add("A");
				}
				if (temp->value == 77)
				{
					listP2->Items->Add("M");
				}
				if (temp->value == 82)
				{
					listP2->Items->Add("R");
				}
				if (temp->value == 86)
				{
					listP2->Items->Add("V");
				}
				temp = temp->next;
			}
		}
		void LlenarPila4() {
			Nodo* temp = mipila4->start;
			listP3->Items->Clear();
			while (temp != nullptr) {
				if (temp->value == 65)
				{
					listP3->Items->Add("A");
				}
				if (temp->value == 77)
				{
					listP3->Items->Add("M");
				}
				if (temp->value == 82)
				{
					listP3->Items->Add("R");
				}
				if (temp->value == 86)
				{
					listP3->Items->Add("V");
				}
				temp = temp->next;
			}
		}

	private: System::Void Medio_Load(System::Object^ sender, System::EventArgs^ e) {
		System::IO::StreamReader^ streamReader = gcnew System::IO::StreamReader("...//PilaDesordenda.txt");
		String^ contenidoArchivo = streamReader->ReadToEnd();
		array<String^>^ Bloques = contenidoArchivo->Split(',');
		int L;
		char letra;
		int contX = 0;
		
		for (int i = 0; i < Bloques->Length; i++)
		{
			letra = Convert::ToChar(Bloques[i]);
			L = Convert::ToInt32(letra);
			if ((char)(L) != 'X')
			{
				if (contX == 0)
				{
					mipila1->InsertAtEnd((char)(L));
					LlenarPila1();
				}
				if (contX == 1)
				{
					mipila2->InsertAtEnd((char)(L));
					LlenarPila2();
				}
				if (contX == 2)
				{
					mipila3->InsertAtEnd((char)(L));
					LlenarPila3();
				}
				if (contX == 3)
				{
					mipila4->InsertAtEnd((char)(L));
					LlenarPila4();
				}
			}
			else
			{
				contX++;
			}
		}
	}
	private: System::Void Medio_FormClosing(System::Object^ sender, System::Windows::Forms::FormClosingEventArgs^ e) {
		System::IO::StreamWriter^ streamWriter = gcnew System::IO::StreamWriter("...//Pasos.txt");
		streamWriter->WriteLine(Pasos);
		streamWriter->Close();
	}
private: System::Void btnMover_Click(System::Object^ sender, System::EventArgs^ e) {
	int PilaOrigen = Convert::ToInt32(txtPilaOrigen->Text);
	int PilaDestino = Convert::ToInt32(txtPilaDestino->Text);
	Movimientos++;
	lblMovimientos->Text = Movimientos.ToString();
	if (Movimientos <= 50)
	{
		if (PilaOrigen != PilaDestino && PilaOrigen >= 0 && PilaOrigen <= 3)
		{
			if (PilaDestino >= 0 && PilaOrigen <= 3)
			{
				if (PilaOrigen == 0)
				{
					if (PilaDestino == 1)
					{
						Nodo* temp = mipila1->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila2->InsertAtEnd(temp->value);
							LlenarPila1();
							LlenarPila2();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 2)
					{
						Nodo* temp = mipila1->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila3->InsertAtEnd(temp->value);
							LlenarPila1();
							LlenarPila3();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 3)
					{
						Nodo* temp = mipila1->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila4->InsertAtEnd(temp->value);
							LlenarPila1();
							LlenarPila4();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
				}
				else if (PilaOrigen == 1)
				{
					if (PilaDestino == 0)
					{
						Nodo* temp = mipila2->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila1->InsertAtEnd(temp->value);
							LlenarPila2();
							LlenarPila1();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 2)
					{
						Nodo* temp = mipila2->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila3->InsertAtEnd(temp->value);
							LlenarPila2();
							LlenarPila3();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 3)
					{
						Nodo* temp = mipila2->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila4->InsertAtEnd(temp->value);
							LlenarPila2();
							LlenarPila4();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
				}
				else if (PilaOrigen == 2)
				{
					if (PilaDestino == 0)
					{
						Nodo* temp = mipila3->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila1->InsertAtEnd(temp->value);
							LlenarPila3();
							LlenarPila1();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 1)
					{
						Nodo* temp = mipila3->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila2->InsertAtEnd(temp->value);
							LlenarPila3();
							LlenarPila2();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 3)
					{
						Nodo* temp = mipila3->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila4->InsertAtEnd(temp->value);
							LlenarPila3();
							LlenarPila4();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
				}
				else if (PilaOrigen == 3)
				{
					if (PilaDestino == 0)
					{
						Nodo* temp = mipila4->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila1->InsertAtEnd(temp->value);
							LlenarPila4();
							LlenarPila1();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 1)
					{
						Nodo* temp = mipila4->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila2->InsertAtEnd(temp->value);
							LlenarPila4();
							LlenarPila2();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
					else if (PilaDestino == 2)
					{
						Nodo* temp = mipila4->ExtractAtEnd();
						if (temp) {
							MessageBox::Show("Se movi� " + temp->value + " de: P" + PilaOrigen.ToString()
								+ " a P" + PilaDestino.ToString(), "Excelente", MessageBoxButtons::OK, MessageBoxIcon::Information);
							mipila3->InsertAtEnd(temp->value);
							LlenarPila4();
							LlenarPila3();
							Pasos += "\n" + "P" + PilaOrigen.ToString() + ", P" + PilaDestino.ToString();
						}
						else {
							MessageBox::Show("La pila est� vac�a", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
						}
					}
				}
			}
		}
		if (mipila1->count > 0 && mipila2->count > 0 && mipila3->count > 0 && mipila4->count > 0)
		{
			if (mipila1->start->value == mipila1->end->value)
			{
				if (mipila2->start->value == mipila2->end->value)
				{
					if (mipila3->start->value == mipila3->end->value)
					{
						if (mipila4->start->value == mipila4->end->value)
						{
							MessageBox::Show("�FELICIDADES!\nHa ganado", "Gan�", MessageBoxButtons::OK, MessageBoxIcon::Information);
							Medio::Close();
						}
					}
				}
			}

		}
	}
	else
	{
		MessageBox::Show("Excedi� el n�mero de movimientos m�ximo del nivel", "Atenci�n", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		Medio::Close();
	}
}
private: System::Void btnAyuda_Click(System::Object^ sender, System::EventArgs^ e) {
	MessageBox::Show("Instrucciones:" +
		"\n	-En los espacios ingrese �nicamente el n�mero de la Pila" +
		"\n	-Posee un l�mite de 50 movimientos" +
		"\n	-Apile los elementos respetando el color de fondo de cada pila"
		"\n	-Para los colores tome en cuenta:" +
		"\n		-Amarillo (A)" + "\n		-Morado (M)" +
		"\n		-Verde (V)" + "\n		-Rojo (R)", "Ayuda", MessageBoxButtons::OK, MessageBoxIcon::Information);

}
};
}
