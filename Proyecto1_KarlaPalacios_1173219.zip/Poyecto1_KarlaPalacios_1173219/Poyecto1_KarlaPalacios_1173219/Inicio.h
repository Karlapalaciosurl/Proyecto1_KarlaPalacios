#pragma once
#include "Facil.h"
#include "Medio.h"
#include "Dificil.h"

namespace Poyecto1KarlaPalacios1173219 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Inicio
	/// </summary>
	public ref class Inicio : public System::Windows::Forms::Form
	{
	public:
		Inicio(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Inicio()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ btnJugar;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::ComboBox^ cbDificultad;

	private: System::Windows::Forms::Label^ label2;
	protected:

	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnJugar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->cbDificultad = (gcnew System::Windows::Forms::ComboBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// btnJugar
			// 
			this->btnJugar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnJugar->Location = System::Drawing::Point(101, 83);
			this->btnJugar->Name = L"btnJugar";
			this->btnJugar->Size = System::Drawing::Size(75, 23);
			this->btnJugar->TabIndex = 0;
			this->btnJugar->Text = L"Jugar";
			this->btnJugar->UseVisualStyleBackColor = true;
			this->btnJugar->Click += gcnew System::EventHandler(this, &Inicio::btnJugar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(95, 8);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(90, 18);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Bienvenido";
			this->label1->Click += gcnew System::EventHandler(this, &Inicio::label1_Click);
			// 
			// cbDificultad
			// 
			this->cbDificultad->FormattingEnabled = true;
			this->cbDificultad->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"F�cil", L"Medio", L"Dif�cil" });
			this->cbDificultad->Location = System::Drawing::Point(79, 51);
			this->cbDificultad->Name = L"cbDificultad";
			this->cbDificultad->Size = System::Drawing::Size(121, 21);
			this->cbDificultad->TabIndex = 2;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(80, 35);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(121, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Seleccione la Dificultad:";
			// 
			// Inicio
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::SteelBlue;
			this->ClientSize = System::Drawing::Size(284, 120);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->cbDificultad);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnJugar);
			this->Name = L"Inicio";
			this->Text = L"Inicio";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void btnJugar_Click(System::Object^ sender, System::EventArgs^ e) {
	if (cbDificultad->SelectedItem == "F�cil")
	{
		Facil^ F = gcnew Facil();
		this->Hide();
		F->ShowDialog(this);
		this->Show();

	}
	if (cbDificultad->SelectedItem == "Medio")
	{
		Medio^ M = gcnew Medio();
		this->Hide();
		M->ShowDialog(this);
		this->Show();
	}
	if (cbDificultad->SelectedItem == "Dif�cil")
	{
		Dificil^ D= gcnew Dificil();
		this->Hide();
		D->ShowDialog(this);
		this->Show();
	}
}
};
}
