#pragma once

class Nodo
{
public:
	char value;
	Nodo* next;

	Nodo();
	~Nodo();
};