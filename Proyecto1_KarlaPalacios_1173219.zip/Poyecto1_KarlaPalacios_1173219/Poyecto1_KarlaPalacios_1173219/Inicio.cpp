#include "Inicio.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace std;

[STAThreadAttribute]
int main(array<String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Poyecto1KarlaPalacios1173219::Inicio form;
	Application::Run(% form);
	return 0;
}