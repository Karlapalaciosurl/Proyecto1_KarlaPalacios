#include "Nodo.h"

Nodo::Nodo() {
	next = nullptr;
};

Nodo::~Nodo() {
	next = nullptr;
};