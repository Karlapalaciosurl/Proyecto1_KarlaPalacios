#include "Pila.h"

Pila::Pila() {
	start = nullptr;
	end = nullptr;
	count = 0;
};

void Pila::InsertAtEnd(char value) {
	Nodo* new_node = new Nodo();
	new_node->value = value;

	if (isEmpty()) {
		start = new_node;
		end = new_node;
	}
	else {
		end->next = new_node;
		end = new_node;
	}
	count++;
}

Nodo* Pila::ExtractAtEnd() {
	Nodo* temp = end;
	if (!isEmpty()) {
		if (count == 1) {
			end = end->next;
			start = end;
		}
		else {
			Nodo* pretemp = start;
			temp = pretemp->next;
			while (temp != end) {
				pretemp = temp;
				temp = pretemp->next;
			}
			pretemp->next = temp->next;
			end = pretemp;
		}
		count--;
	}
	return temp;
}

bool Pila::isEmpty() {
	return count == 0;
}