#pragma once
#include "Nodo.h"

class Pila
{
public:
	Nodo* start;
	Nodo* end;
	int count;

	Pila();
	void InsertAtEnd(char value);
	Nodo* ExtractAtEnd();
	bool isEmpty();
	~Pila() {};
};